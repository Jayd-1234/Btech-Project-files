function prob = step_sens_tmax(xsag, ysag, xmin, xmax, ymin, ymax, eta)

prob = zeros(size(xsag));
for i=1:length(ysag)
    if ((xsag(i)>=xmin) && (xsag(i) <=xmax) || (ysag(i)>=ymax) && (ysag(i)<=ymin))
        prob(i) = (exp(log(2)*(xsag(i)-xmin)/(xmax-xmin))-1)*(exp(log(2)*(ymin-ysag(i))/(ymin-ymax))-1);
    end
    
    if (xsag(i) <xmin) && (ysag(i) > ymin)
        prob(i) = 0;
    end
    
    if (xsag(i) > xmax) && (ysag(i) <ymax)
        prob(i) = 1;
    end
    
end

    
    